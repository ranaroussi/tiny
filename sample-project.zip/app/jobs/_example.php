<?php

class Hello
{
    public function world($s = 'there')
    {
        return "Hello $s, World!";
    }
}
