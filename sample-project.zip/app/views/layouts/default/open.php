<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover">
    <meta http-equiv="cleartype" content="on">
    <title><?php echo Layout->props('title') ? strip_tags(Layout->props('title')) . ' - ' : '' ?>Tiny: PHP Framework</title>

    <meta name="robots" content="index, follow">
    <link rel="stylesheet" type="text/css" href="<?php tiny::staticURL('css/style.css') ?>" media="all">
    <link rel="shortcut icon" href="<?php tiny::staticURL('favicon.png') ?>" type="image/png">

</head>

<body>
    <div class="container">
