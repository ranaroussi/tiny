<?php Layout->default(title: '404'); ?>

404

<?php Layout->default(); ?>
