<?php
// this file is loaded by tiny on startup
// put any code you need to run on startup here
// ...
