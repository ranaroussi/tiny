<?php
// include tiny
require_once '../tiny/tiny.php';

/* ----------------------------------- */
// any code you need to run before the controller
// is called goes here ↓
// ...
/* ----------------------------------- */


// run controller
tiny::controller();

